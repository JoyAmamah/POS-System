import React, { useState, useEffect } from "react";
import { Outlet } from "react-router-dom";
import {
  PackageCheck,
  LogOut,
  LayoutDashboardIcon,
  UserPen,
  Store,
  UsersRound,
  ChartBarStacked,
  ScanBarcode,
  Package,
  ShoppingCart,
  Proportions,
  BellDot,
} from "lucide-react";

const DashboardLayout = () => {
  const [date, setDate] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setDate(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  return (
    <div className="flex flex-row p-2 min-h-screen">
  
      <div className="flex flex-grow">
  
      <div className="w-16 md:w-48 bg-slate-900 text-white flex flex-col p-2 gap-2 rounded-lg transition-all duration-300">
  {[
    { icon: <LayoutDashboardIcon size={24} />, label: "Dashboard" },
    { icon: <Store size={24} />, label: "Stores" },
    { icon: <UserPen size={24} />, label: "Users" },
    { icon: <UsersRound size={24} />, label: "Suppliers" },
    { icon: <ChartBarStacked size={24} />, label: "Category" },
    { icon: <Package size={24} />, label: "Products" },
    { icon: <ScanBarcode size={24} />, label: "Barcode Scanner" },
    { icon: <ShoppingCart size={24} />, label: "Orders" },
    { icon: <Proportions size={24} />, label: "Report" },
    { icon: <PackageCheck size={24} />, label: "Product Activation" },
  ].map((item, index) => (
    <button
      key={index}
      className="relative flex items-center md:items-center justify-center md:justify-start gap-3 p-3 rounded-md hover:bg-slate-700 transition-all w-full group"
    >
      <span>{item.icon}</span>
      <span className="hidden md:block text-sm font-normal">{item.label}</span>
      <span className="absolute left-14 md:hidden bg-slate-800 text-white px-2 py-1 text-sm rounded-md opacity-0 group-hover:opacity-100 transition-all duration-200">
        {item.label}
      </span>
    </button>
  ))}

  <button className="relative flex items-center md:items-center justify-center md:justify-start gap-3 text-red-400 hover:text-red-500 hover:bg-slate-700 p-3 rounded-md w-full group">
    <LogOut size={24} />
    <span className="hidden md:block text-sm font-medium">Logout</span>
    <span className="absolute left-14 md:hidden bg-slate-800 text-white px-2 py-1 text-sm rounded-md opacity-0 group-hover:opacity-100 transition-all duration-200">
      Logout
    </span>
  </button>
</div>





<div className="flex-1">
  <div className="flex justify-between items-center px-2 sm:px-4 h-14 text-white">
    <div className="p-2 w-80 sm:w-48 font-bold text-xs sm:text-sm bg-slate-500 rounded-md hidden sm:block">
      <p>POS (Point of Sales) V3.0</p>
    </div>

     <div className="flex items-center gap-4 sm:gap-6 ml-auto">
    <span className="text-sm sm:text-lg bg-slate-600 px-4 py-2 rounded-md">
        {date.toLocaleTimeString()}
      </span>
      <button className="p-1 sm:p-2 bg-slate-600 rounded-md hover:bg-slate-700">
        <BellDot size={20} sm:size={16} />
      </button>
    </div>
  </div>

  <Outlet />
</div>



      </div>
      {/* <div>
        <p>meeeeeeeennnnnneeee</p>
      </div> */}
    </div>
  );
};

export default DashboardLayout;
