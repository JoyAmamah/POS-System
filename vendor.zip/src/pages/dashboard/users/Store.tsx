import {
    Button,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    Paper,
    Modal,
    Box,
    Typography,
    TextField,
    FormControl,
    InputLabel,
    MenuItem,
    Select,
    Pagination,
    Stack,
  } from "@mui/material";
import axios from "axios";
  import React, { useState } from "react";
  
  const style = {
    position: "absolute",
    top: "50%",
    left: "50%",
    transform: "translate(-50%, -50%)",
    width: "90vw",
    maxWidth: "400px",
    bgcolor: "background.paper",
    borderRadius: "10px",
    boxShadow: 24,
    p: 4,
  };
  
  const Store = () => {
    const [open, setOpen] = useState(false);
    const [editOpen, setEditOpen] = useState(false);
    const [selectedStore, setSelectedStore] = useState(null);
    const [value, setValue] = useState({
        name: "",
        address: "",
        email: "",
        phone: "",
      });
  
    const handleOpen = () => setOpen(true);
    const handleClose = () => setOpen(false);
    const handleEditOpen = (store) => {
      setSelectedStore(store);
      setEditOpen(true);
    };
    const handleEditClose = () => {
      setSelectedStore(null);
      setEditOpen(false);
    };

    const handleDelete = async () => {
        try {
          const res = await axios.delete(
            "http://192.168.0.136:8001/api/v1/vendors",
            value
          );
          console.log(res.data);
        } catch (error: any) {
          console.error(error);
          console.error("Something went wrong. Please try again.");
        }
      };
      
  
    const stores = [
      {
        name: "Store A",
        location: "Lagos",
        manager: "Shola Coker",
        email: "storea@example.com",
        phone: "123-456-7890",
        status: "close",
      },
      {
        name: "Store B",
        location: "Kano",
        manager: "John Doe",
        email: "storeb@example.com",
        phone: "987-654-3210",
        status: "open",
      },
    ];
  
    return (
      <div className="p-4 flex flex-col h-full">
        <h1 className="text-lg sm:text-xl font-bold">STORES</h1>
  
        <div className="flex flex-wrap justify-between items-center mb-4 gap-2">
          <div className="flex flex-row gap-48 w-full">
            <TextField
              label="Search"
              type="search"
              variant="outlined"
              className="w-full rounded-lg shadow-md"
            />
  
            <Button onClick={handleOpen} variant="contained" color="primary">
              + Add Store
            </Button>
          </div>
        </div>
  
        <Modal open={open} onClose={handleClose}>
      
         <Box sx={style}>
            <Typography variant="h6" className="mb-4">
              Add New Store
            </Typography>
            <div className="flex flex-col space-y-4">
            <TextField fullWidth label="Full Name" variant="outlined" className="mb-3" />
            <TextField fullWidth label="Manager" variant="outlined" className="mb-3" />
            <TextField fullWidth label="Location" variant="outlined" className="mb-3" />
            <TextField fullWidth label="Store Phone" type="tel" variant="outlined" className="mb-3" />
            <FormControl fullWidth className="mb-3">
              <InputLabel>Status</InputLabel>
              <Select>
                <MenuItem value="open">Open</MenuItem>
                <MenuItem value="close">Close</MenuItem>
              </Select>
            </FormControl>
            <div className="flex justify-end gap-4">
              <Button variant="outlined" color="secondary" onClick={handleClose}>
                Dismiss
              </Button>
              <Button variant="contained" color="primary">
                Submit
              </Button>
            </div>
            </div>
          </Box>
      
        </Modal>
  
        <TableContainer component={Paper} className="w-full max-h-100vh overflow-hidden">
          <Table className="min-w-full">
            <TableHead>
              <TableRow>
                {["Name", "Location", "Manager", "Email", "Phone", "Status", "Action"].map((head) => (
                  <TableCell key={head} className="font-bold text-sm break-words">
                    {head}
                  </TableCell>
                ))}
              </TableRow>
            </TableHead>
            <TableBody>
              {stores.map((store, index) => (
                <TableRow key={index}>
                  <TableCell className="text-sm break-words">{store.name}</TableCell>
                  <TableCell className="text-sm break-words">{store.location}</TableCell>
                  <TableCell className="text-sm break-words">{store.manager}</TableCell>
                  <TableCell className="text-sm break-words">{store.email}</TableCell>
                  <TableCell className="text-sm break-words">{store.phone}</TableCell>
                  <TableCell className="text-sm break-words">{store.status}</TableCell>
                  <TableCell>
                  <div className="flex gap-2">
  <Button 
    variant="outlined" 
    color="error" 
    onClick={() => handleDelete()}
  >
    Delete
  </Button>
  <Button 
    variant="contained" 
    color="primary" 
    onClick={() => handleEditOpen(store)}
  >
    Edit
  </Button>
</div>

                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
  
        <Modal open={editOpen} onClose={handleEditClose}>
          <Box sx={style}>
          <div className="flex flex-col space-y-4">
            <Typography variant="h6" className="mb-4">
              Edit Store
            </Typography>
            <TextField
              fullWidth
              label="Full Name"
              variant="outlined"
              className="mb-3"
              defaultValue={selectedStore?.name}
            />
            <TextField
              fullWidth
              label="Manager"
              variant="outlined"
              className="mb-3"
              defaultValue={selectedStore?.manager}
            />
            <TextField
              fullWidth
              label="Location"
              variant="outlined"
              className="mb-3"
              defaultValue={selectedStore?.location}
            />
            <TextField
              fullWidth
              label="Store Phone"
              type="tel"
              variant="outlined"
              className="mb-3"
              defaultValue={selectedStore?.phone}
            />
            <FormControl fullWidth className="mb-3">
              <InputLabel>Status</InputLabel>
              <Select defaultValue={selectedStore?.status}>
                <MenuItem value="open">Open</MenuItem>
                <MenuItem value="close">Close</MenuItem>
              </Select>
            </FormControl>
            <div className="flex justify-end gap-4">
              <Button variant="outlined" color="secondary" onClick={handleEditClose}>
                Dismiss
              </Button>
              <Button variant="contained" color="primary">
                Save Changes
              </Button>
            </div>
            </div>
          </Box>
        </Modal>
  
        <div className="w-full flex justify-center mt-auto bg-white shadow-md p-4 rounded-lg">
          <Stack spacing={2}>
            <Pagination count={10} variant="outlined" shape="rounded" />
          </Stack>
        </div>
      </div>
    );
  };
  
  export default Store;
  